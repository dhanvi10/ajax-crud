<!doctype html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- <script src="jquery.min.js"></script> -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link rel="stylesheet" href="css.css">
    <title>PHP - AJAX - CRUD</title>
</head>
<body>



        <!-- ADD MODAL -->
<div class="modal fade" id="student_addmodel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog model-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add student data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class = "row">
            <div class = "col-md-12">
                <div class = "error-message">

                </div>
            </div>
            <div class = "col-md-12">
                <label for="">First name</label>
                <input type="text" class = "form-control fname">
            </div>
            <div class = "col-md-12">
                <label for="">Last name</label>
                <input type="text" class = "form-control lname">
            </div>
            <div class = "col-md-12">
                <label for="">Address</label>
                <input type="text" class = "form-control add">
            </div>
            <div class = "col-md-12">
                <label for="">Blood group</label>
                <input type="text" class = "form-control bgrp">
            </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary student_add_ajax">Add</button>
      </div>
    </div>
  </div>
</div>

<!-- view modal -->
<div class="modal fade" id="student_viewmodel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"> Student view detail</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
                    <h4 class="id_view"></h4>
                    <h4 class="fname_view"></h4>
                    <h4 class="lname_view"></h4>
                    <h4 class="class_view"></h4>
                    <h4 class="section_view"></h4>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

 <!-- Edit Modal -->
 <div class="modal fade" id="StudentEditModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Student Data </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                    <div class="row">
                        <input type="hidden" id="id_edit">

                        <div class="col-md-12">
                            <div class="error-message-update">

                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="">First Name</label>
                            <input type="text" id="edit_fname" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="">Last Name</label>
                            <input type="text" id="edit_lname" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="">Address</label>
                            <input type="text" id="edit_add" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="">Blood group</label>
                            <input type="text" id="edit_bgrp" class="form-control">
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary student_update_ajax">Update</button>
            </div>
            </div>
        </div>
    </div>

<!-- table -->
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>
                            Student Records
                            <input class="form-control col-md-5 float-right" type="search" id="search" placeholder="Search" aria-label="Search"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <button type="button" class=" btn btn-secondary " data-toggle="modal" data-target="#student_addmodel">
                                Add Records
                            </button>&nbsp;&nbsp;&nbsp;&nbsp;
                            
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="message-show">

                        </div>
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>First Name</th>
                                    <th>Last name</th>
                                    <th>Adress</th>
                                    <th>Blood Group</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody class="studentdata">

                            </tbody>
                        </table>

                        
                       <!-- <nav aria-label="...">
                            <ul class="pagination pagination-lg">
                                <li class="page-item">
                                     <a id="1" class="page-link" href="#" >1</a>
                                </li>
                                <li class="page-item"><a id="2" class="page-link" href="#">2</a></li>
                                <li class="page-item"><a id="3" class="page-link" href="#">3</a></li>
                            </ul>
                        </nav> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function () 
        {
            getdata();
        //     $("#target-content").load("pagination.php?page=1");
		//     $(".page-link").click(function(){
		// 	var id = $(this).attr("id");
		// 	var select_id = $(this).parent().attr("id");
		// 	$.ajax({
		// 		url: "pagination.php",
		// 		type: "GET",
		// 		data: {
		// 			page : id
		// 		},
		// 		cache: false,
		// 		success: function(dataResult){
		// 			$(".studentdata").html(response);
		// 			$(".pageitem").removeClass("page-link");
		// 			$("#"+select_id).addClass("page-link");
					
		// 		}
		// 	});
		// });
            $(document).on("click", ".page-item a", function (e) {
                e.preventDefault();
                var page_id = $(this).attr("id");
                getdata(page_id);
            });

            $('#search').on("keyup", function () {
            var search = $(this).val();

                $.ajax({
                    type: "POST",
                    url: "ajax-crud/code.php",
                    data: {
                        'checking_search' : true,
                    'search': search},
                    success: function (response) {
                        // console.log(response)
                    //     $.each(student, function (key, value)
                    // {
                        // $('.studentdata').append('<tr>'+
                        //         '<td class="stud_id">'+value['id']+'</td>\
                        //         <td>'+value['fname']+'</td>\
                        //         <td>'+value['lname']+'</td>\
                        //         <td>'+value['adress']+'</td>\
                        //         <td>'+value['bloodgroup']+'</td>\
                        //         <td>\
                        //             <a href="#" class="btn btn-dark viewbtn">VIEW</a>\
                        //             <a href="#" class="btn btn-dark edit_btn">EDIT</a>\
                        //             <a href="#" class="btn btn-dark btndelete">DELETE</a>\
                        //         </td>\
                        //     </tr>');
                    // });
                        $('.studentdata').html(response);
                    }
                });
            });
        

            $(document).on("click", ".btndelete", function () {
                var stud_id = $(this).closest('tr').find('.stud_id').text();
                $.ajax({
                    type: "POST",
                    url: "ajax-crud/code.php",
                    data: {
                        'checking_delete' : true,
                        'stud_id': stud_id,
                    },
                    success: function (response) {
                        $('.message-show').append('\
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">\
                                        <strong>Hey!</strong>'+ response+' Record deleted..!\
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">\
                                            <span aria-hidden="true">&times;</span>\
                                        </button>\
                                    </div>\
                            ');
                            $('.studentdata').html("");
                            getdata();
                        // $('#deletedata').modal('show');
                        
                    }
                });

            });
            $('.student_update_ajax').click(function (e) { 
                e.preventDefault();
                var stud_id = $('#id_edit').val();
                var fname = $('#edit_fname').val();
                var lname = $('#edit_lname').val();
                var add = $('#edit_add').val();
                var bgrp = $('#edit_bgrp').val();
                // console.log(fname);
                if(fname != '' & lname != '' & add != '' & bgrp != '' )
                {
                    $.ajax
                    ({
                        type: "POST",
                        url: "ajax-crud/code.php",
                        data:
                        {
                            'cheking_update':true,
                            'stud_id': stud_id,
                            'fname':fname,
                            'lname':lname,
                            'add':add,
                            'bgrp':bgrp,
                        },    
                        success: function (response) {
                            // console.log(response);
                            $('#StudentEditModal').modal('hide');
                            $('.message-show').append('\
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">\
                                        <strong>Hey!</strong>'+ response+' Record Updated..!\
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">\
                                            <span aria-hidden="true">&times;</span>\
                                        </button>\
                                    </div>\
                            ');
                            $('.studentdata').html("");
                            getdata();

                        }
                    });
                }
                else
                {
                            $('.error-message-update').append('\
                                <div class="alert alert-warning alert-dismissible fade show" role="alert">\
                                    <strong>Hey!</strong> please fill every fields.!\
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">\
                                            <span aria-hidden="true">&times;</span>\
                                        </button>\
                                </div>\
                            ');
                }
            });
      


                $(document).on("click", ".edit_btn", function () {
                    var stud_id = $(this).closest('tr').find('.stud_id').text();
                    // alert(stud_id);

                        $.ajax
                        ({
                            type: "POST",
                            url: "ajax-crud/code.php",
                            data: 
                            {
                                'checking_edit': true,
                                'stud_id': stud_id,
                            },
                            success: function (response) 
                            {
                                // console.log(response);
                                $.each(response, function (key, studedit) { 
                                    // console.log(studview['fname']);
                                    $('#id_edit').val(studedit['id']);
                                    $('#edit_fname').val(studedit['fname']);
                                    $('#edit_lname').val(studedit['lname']);
                                    $('#edit_add').val(studedit['adress']);
                                    $('#edit_bgrp').val(studedit['bloodgroup']);
                                });
                                $('#StudentEditModal').modal('show');
                            }
                        });

                });

                $(document).on("click", ".viewbtn", function () {

                        var stud_id = $(this).closest('tr').find('.stud_id').text();
                        // alert(stud_id);

                        $.ajax
                        ({
                            type: "POST",
                            url: "ajax-crud/code.php",
                            data: 
                            {
                                'checking_view': true,
                                'stud_id': stud_id,
                            },
                            success: function (response) {
                                $.each(response, function (key, studview) 
                                { 
                                    $('.id_view').text(studview['id']);
                                    $('.fname_view').text(studview['fname']);
                                    $('.lname_view').text(studview['lname']);
                                    $('.class_view').text(studview['adress']);
                                    $('.section_view').text(studview['bloodgroup']);
                                });
                                     $('#student_viewmodel').modal('show');
                            }

                        }); 
               
                    });

                $('.student_add_ajax').click(function (e) { 
                     e.preventDefault();

                    var fname = $('.fname').val();
                    var lname = $('.lname').val();
                    var add = $('.add').val();
                    var bgrp = $('.bgrp').val();
                    // console.log(fname);
                    if(fname != '' & lname != '' & add != '' & bgrp != '' )
                    {
                        $.ajax
                        ({
                            type: "POST",
                            url: "ajax-crud/code.php",
                            data:
                            {
                                'cheking_add':true,
                                'fname':fname,
                                'lname':lname,
                                'add':add,
                                'bgrp':bgrp,
                            },    
                             success: function (response) 
                            {
                                // console.log(response);
                                $('#student_addmodel').modal('hide');
                                $('.message-show').append('\
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">\
                                        <strong>Hey!</strong>'+ response+' Record inserted..!\
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">\
                                            <span aria-hidden="true">&times;</span>\
                                        </button>\
                                    </div>\
                                ');
                                $('.studentdata').html("");
                                getdata();
                                $('.fname').val("");
                                $('.lname').val("");
                                $('.add').val("");
                                $('.bgrp').val("");
                            }
                        });
                }
                else
                {
                            $('.error-message').append('\
                                <div class="alert alert-warning alert-dismissible fade show" role="alert">\
                                    <strong>Hey!</strong> please fill every fields.!\
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">\
                                            <span aria-hidden="true">&times;</span>\
                                        </button>\
                                </div>\
                            ');
                }
            });
        });


        function getdata(page)
        {
            $.ajax({
                type: "POST",
                url: "ajax-crud/pagination.php",
                data: {
                    'page_id' : page,
                    // 'limit':limit
                },
                success: function (response) {
                    $('.studentdata').html(response);
                    $(".page-item").removeClass("page-link");
					// $("#"+select_id).addClass("page-link");
                    
                }
            });
            // $.ajax
            // ({
            //     type: "POST",
            //     url: "ajax-crud/fetch.php",
            //     success: function (student) 
            //     {
            //         $.each(student, function (key, value)
            //         {
            //             // console.log(value['fname']);
            //             $('.studentdata').append('<tr>'+
            //                     '<td class="stud_id">'+value['id']+'</td>\
            //                     <td>'+value['fname']+'</td>\
            //                     <td>'+value['lname']+'</td>\
            //                     <td>'+value['adress']+'</td>\
            //                     <td>'+value['bloodgroup']+'</td>\
            //                     <td>\
            //                         <a href="#" class="btn btn-dark viewbtn">VIEW</a>\
            //                         <a href="#" class="btn btn-dark edit_btn">EDIT</a>\
            //                         <a href="#" class="btn btn-dark btndelete">DELETE</a>\
            //                     </td>\
            //                 </tr>');
            //         });
            //     }
            // });
        }
    </script>

  </body>
</html>
